from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    sport = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    location = db.Column(db.String(200), nullable=False)
    location_link = db.Column(db.String(500))
    date = db.Column(db.DateTime, nullable=False)
    max_participants = db.Column(db.Integer, default=20)
    current_participants = db.Column(db.Integer, default=0)
    organizer = db.Column(db.String(100), nullable=False)
    image_url = db.Column(db.String(500))
    tags = db.Column(db.String(200))  # Comma-separated tags
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign key to User (if implementing user authentication)
    # user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    def __repr__(self):
        return f'<Event {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'sport': self.sport,
            'description': self.description,
            'location': self.location,
            'location_link': self.location_link,
            'date': self.date.isoformat() if self.date else None,
            'max_participants': self.max_participants,
            'current_participants': self.current_participants,
            'organizer': self.organizer,
            'image_url': self.image_url,
            'tags': self.tags.split(',') if self.tags else [],
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

