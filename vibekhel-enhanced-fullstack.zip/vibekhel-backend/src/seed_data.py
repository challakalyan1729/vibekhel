import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime, timedelta
from src.models.user import db
from src.models.event import Event
from src.main import app

def seed_events():
    """Seed the database with initial event data"""
    with app.app_context():
        # Clear existing events
        Event.query.delete()
        
        # Create sample events
        events_data = [
            {
                'title': 'Gully Cricket Championship',
                'sport': 'cricket',
                'description': 'Join us for an exciting gully cricket tournament featuring teams from across the region.',
                'location': 'Junior College Ground, Samalkot',
                'location_link': 'https://maps.app.goo.gl/VagWdqhTn2WTmJJW9?g_st=awb',
                'date': datetime.now() + timedelta(days=2),
                'max_participants': 40,
                'current_participants': 12,
                'organizer': 'Vetlapalem Sports Club',
                'image_url': '/assets/gully-cricket-Bw0zgDpT.jpeg',
                'tags': 'Tournament,Prize Money,All Ages'
            },
            {
                'title': 'Traditional Kabaddi Match',
                'sport': 'kabaddi',
                'description': 'Experience the thrill of traditional kabaddi in an authentic village setting.',
                'location': 'Community Center, Samalkot',
                'location_link': 'https://maps.app.goo.gl/VagWdqhTn2WTmJJW9?g_st=awb',
                'date': datetime.now() + timedelta(days=3),
                'max_participants': 24,
                'current_participants': 18,
                'organizer': 'Samalkot Youth Association',
                'image_url': '/assets/kabaddi-ikGkKBlv.jpg',
                'tags': 'Traditional,Cultural,Team Sport'
            },
            {
                'title': 'Street Chess Tournament',
                'sport': 'chess',
                'description': 'Test your strategic skills in our outdoor chess championship.',
                'location': 'Community Center, Samalkot',
                'location_link': 'https://maps.app.goo.gl/VagWdqhTn2WTmJJW9?g_st=awb',
                'date': datetime.now() + timedelta(days=4),
                'max_participants': 40,
                'current_participants': 32,
                'organizer': 'Samalkot Chess Club',
                'image_url': '/assets/street-chess-dJolFB_X.jpg',
                'tags': 'Mental Sport,Strategy,All Levels'
            },
            {
                'title': 'Beach Volleyball Fest',
                'sport': 'volleyball',
                'description': 'Spike your way to victory in our exciting volleyball tournament.',
                'location': 'Village Court, Vetlapalem',
                'location_link': 'https://maps.app.goo.gl/7vNgQ8saNPJTxBXeA?g_st=awb',
                'date': datetime.now() + timedelta(days=5),
                'max_participants': 24,
                'current_participants': 18,
                'organizer': 'Coastal Sports Federation',
                'image_url': '/assets/volleyball-CXyMGI5u.jpg',
                'tags': 'Beach Sport,Team Play,Fun'
            }
        ]
        
        for event_data in events_data:
            event = Event(**event_data)
            db.session.add(event)
        
        db.session.commit()
        print(f"Successfully seeded {len(events_data)} events!")

if __name__ == '__main__':
    seed_events()

