from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.user import db
from src.models.event import Event

event_bp = Blueprint('event', __name__)

@event_bp.route('/events', methods=['GET'])
def get_events():
    """Get all events with optional filtering"""
    try:
        # Get query parameters
        sport = request.args.get('sport')
        location = request.args.get('location')
        date_filter = request.args.get('date_filter')
        search = request.args.get('search')
        
        # Start with all events
        query = Event.query
        
        # Apply filters
        if sport and sport != 'all':
            query = query.filter(Event.sport == sport)
            
        if location:
            query = query.filter(Event.location.contains(location))
            
        if search:
            query = query.filter(
                Event.title.contains(search) | 
                Event.description.contains(search) |
                Event.location.contains(search)
            )
            
        # Date filtering
        if date_filter and date_filter != 'all':
            now = datetime.now()
            if date_filter == 'today':
                query = query.filter(db.func.date(Event.date) == now.date())
            elif date_filter == 'tomorrow':
                tomorrow = datetime(now.year, now.month, now.day + 1)
                query = query.filter(db.func.date(Event.date) == tomorrow.date())
            elif date_filter == 'week':
                week_later = datetime(now.year, now.month, now.day + 7)
                query = query.filter(Event.date.between(now, week_later))
        
        # Order by date
        events = query.order_by(Event.date.asc()).all()
        
        return jsonify([event.to_dict() for event in events])
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events', methods=['POST'])
def create_event():
    """Create a new event"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'sport', 'location', 'date', 'organizer']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Parse date
        try:
            event_date = datetime.fromisoformat(data['date'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'error': 'Invalid date format'}), 400
        
        # Create new event
        event = Event(
            title=data['title'],
            sport=data['sport'],
            description=data.get('description', ''),
            location=data['location'],
            location_link=data.get('location_link', ''),
            date=event_date,
            max_participants=data.get('max_participants', 20),
            organizer=data['organizer'],
            image_url=data.get('image_url', ''),
            tags=','.join(data.get('tags', []))
        )
        
        db.session.add(event)
        db.session.commit()
        
        return jsonify(event.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events/<int:event_id>', methods=['GET'])
def get_event(event_id):
    """Get a specific event by ID"""
    try:
        event = Event.query.get_or_404(event_id)
        return jsonify(event.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events/<int:event_id>', methods=['PUT'])
def update_event(event_id):
    """Update an existing event"""
    try:
        event = Event.query.get_or_404(event_id)
        data = request.get_json()
        
        # Update fields if provided
        if 'title' in data:
            event.title = data['title']
        if 'sport' in data:
            event.sport = data['sport']
        if 'description' in data:
            event.description = data['description']
        if 'location' in data:
            event.location = data['location']
        if 'location_link' in data:
            event.location_link = data['location_link']
        if 'date' in data:
            event.date = datetime.fromisoformat(data['date'].replace('Z', '+00:00'))
        if 'max_participants' in data:
            event.max_participants = data['max_participants']
        if 'organizer' in data:
            event.organizer = data['organizer']
        if 'image_url' in data:
            event.image_url = data['image_url']
        if 'tags' in data:
            event.tags = ','.join(data['tags'])
            
        event.updated_at = datetime.utcnow()
        
        db.session.commit()
        return jsonify(event.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events/<int:event_id>', methods=['DELETE'])
def delete_event(event_id):
    """Delete an event"""
    try:
        event = Event.query.get_or_404(event_id)
        db.session.delete(event)
        db.session.commit()
        return jsonify({'message': 'Event deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events/<int:event_id>/join', methods=['POST'])
def join_event(event_id):
    """Join an event (increment participant count)"""
    try:
        event = Event.query.get_or_404(event_id)
        
        if event.current_participants >= event.max_participants:
            return jsonify({'error': 'Event is full'}), 400
            
        event.current_participants += 1
        db.session.commit()
        
        return jsonify(event.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@event_bp.route('/events/<int:event_id>/leave', methods=['POST'])
def leave_event(event_id):
    """Leave an event (decrement participant count)"""
    try:
        event = Event.query.get_or_404(event_id)
        
        if event.current_participants > 0:
            event.current_participants -= 1
            db.session.commit()
        
        return jsonify(event.to_dict())
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

