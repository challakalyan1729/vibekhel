import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Search, MapPin, Calendar, Clock, Users, Plus, Menu, X, Star, Heart, Share2, Filter, ChevronDown } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import './App.css'

// Import images
import heroImage from './assets/street-sports-hero.jpg'
import gullyCricketImage from './assets/gully-cricket.jpeg'
import kabaddiImage from './assets/kabaddi.jpg'
import chessImage from './assets/street-chess.jpg'
import volleyballImage from './assets/volleyball.jpg'

function App() {
  const [events, setEvents] = useState([
    {
      id: 1,
      sport: 'cricket',
      title: 'Gully Cricket Championship',
      location: 'High School Ground, Vetlapalem',
      locationLink: 'https://maps.app.goo.gl/7vNgQ8saNPJTxBXeA?g_st=awb',
      date: '2025-07-12T16:00:00Z',
      image: gullyCricketImage,
      participants: 24,
      maxParticipants: 30,
      description: 'Join us for an exciting gully cricket tournament featuring teams from across the region.',
      organizer: 'Vetlapalem Sports Club',
      tags: ['Tournament', 'Prize Money', 'All Ages']
    },
    {
      id: 2,
      sport: 'kabaddi',
      title: 'Traditional Kabaddi Match',
      location: 'Junior College Ground, Samalkot',
      locationLink: 'https://maps.app.goo.gl/VagWdqhTn2WTmJJW9?g_st=awb',
      date: '2025-07-13T18:00:00Z',
      image: kabaddiImage,
      participants: 16,
      maxParticipants: 20,
      description: 'Experience the thrill of traditional kabaddi in an authentic village setting.',
      organizer: 'Samalkot Youth Association',
      tags: ['Traditional', 'Cultural', 'Team Sport']
    },
    {
      id: 3,
      sport: 'chess',
      title: 'Street Chess Tournament',
      location: 'Community Center, Samalkot',
      locationLink: 'https://maps.app.goo.gl/VagWdqhTn2WTmJJW9?g_st=awb',
      date: '2025-07-14T10:00:00Z',
      image: chessImage,
      participants: 32,
      maxParticipants: 40,
      description: 'Test your strategic skills in our outdoor chess championship.',
      organizer: 'Samalkot Chess Club',
      tags: ['Mental Sport', 'Strategy', 'All Levels']
    },
    {
      id: 4,
      sport: 'volleyball',
      title: 'Beach Volleyball Fest',
      location: 'Village Court, Vetlapalem',
      locationLink: 'https://maps.app.goo.gl/7vNgQ8saNPJTxBXeA?g_st=awb',
      date: '2025-07-15T17:00:00Z',
      image: volleyballImage,
      participants: 18,
      maxParticipants: 24,
      description: 'Spike your way to victory in our exciting volleyball tournament.',
      organizer: 'Coastal Sports Federation',
      tags: ['Beach Sport', 'Team Play', 'Fun']
    }
  ])

  const [filteredEvents, setFilteredEvents] = useState(events)
  const [selectedSport, setSelectedSport] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [dateFilter, setDateFilter] = useState('all')
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false)
  const [likedEvents, setLikedEvents] = useState(new Set())

  const sports = [
    { id: 'all', name: 'All Sports', icon: '🏆', color: 'bg-gray-100' },
    { id: 'cricket', name: 'Cricket', icon: '🏏', color: 'bg-orange-100' },
    { id: 'kabaddi', name: 'Kabaddi', icon: '🤼', color: 'bg-red-100' },
    { id: 'chess', name: 'Chess', icon: '♟️', color: 'bg-blue-100' },
    { id: 'volleyball', name: 'Volleyball', icon: '🏐', color: 'bg-green-100' }
  ]

  useEffect(() => {
    let filtered = events

    if (selectedSport !== 'all') {
      filtered = filtered.filter(event => event.sport === selectedSport)
    }

    if (searchTerm) {
      filtered = filtered.filter(event =>
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (dateFilter !== 'all') {
      const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)
      const nextWeek = new Date(today)
      nextWeek.setDate(nextWeek.getDate() + 7)

      filtered = filtered.filter(event => {
        const eventDate = new Date(event.date)
        const eventDay = new Date(eventDate.getFullYear(), eventDate.getMonth(), eventDate.getDate())

        switch (dateFilter) {
          case 'today':
            return eventDay.getTime() === today.getTime()
          case 'tomorrow':
            return eventDay.getTime() === tomorrow.getTime()
          case 'week':
            return eventDate >= today && eventDate <= nextWeek
          default:
            return true
        }
      })
    }

    setFilteredEvents(filtered)
  }, [events, selectedSport, searchTerm, dateFilter])

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    })
  }

  const formatTime = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })
  }

  const toggleLike = (eventId) => {
    const newLikedEvents = new Set(likedEvents)
    if (newLikedEvents.has(eventId)) {
      newLikedEvents.delete(eventId)
    } else {
      newLikedEvents.add(eventId)
    }
    setLikedEvents(newLikedEvents)
  }

  const handleCreateEvent = (formData) => {
    const newEvent = {
      id: events.length + 1,
      sport: formData.sport,
      title: formData.title,
      location: formData.location,
      locationLink: '#',
      date: formData.datetime,
      image: sports.find(s => s.id === formData.sport)?.icon || '🏆',
      participants: 0,
      maxParticipants: parseInt(formData.maxParticipants) || 20,
      description: formData.description,
      organizer: 'You',
      tags: ['New Event']
    }
    setEvents([...events, newEvent])
    setIsCreateEventOpen(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <motion.nav 
        className="fixed top-0 w-full z-50 nav-blur"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              className="text-2xl font-bold text-gradient"
              whileHover={{ scale: 1.05 }}
            >
              Vibekhel
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              <Button variant="ghost" className="hover:text-primary">Browse Events</Button>
              <Dialog open={isCreateEventOpen} onOpenChange={setIsCreateEventOpen}>
                <DialogTrigger asChild>
                  <Button className="btn-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Event
                  </Button>
                </DialogTrigger>
                <CreateEventDialog onSubmit={handleCreateEvent} />
              </Dialog>
              <Button variant="outline">Sign In</Button>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>

          {/* Mobile Navigation */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                className="md:hidden mt-4 pb-4 border-t border-border"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex flex-col space-y-2 pt-4">
                  <Button variant="ghost" className="justify-start">Browse Events</Button>
                  <Button variant="ghost" className="justify-start" onClick={() => setIsCreateEventOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Event
                  </Button>
                  <Button variant="outline" className="justify-start">Sign In</Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 hero-gradient opacity-90"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Join India's Street Sports Revolution!
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl mb-8 opacity-90"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Connect with enthusiasts for gully cricket, kabaddi, chess, volleyball, and more.
          </motion.p>
          
          <motion.div 
            className="flex justify-center space-x-4 mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            {['🏏', '🤼', '♟️', '🏐'].map((emoji, index) => (
              <span key={index} className="text-6xl sport-icon float-animation" style={{ animationDelay: `${index * 0.2}s` }}>
                {emoji}
              </span>
            ))}
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Button 
              size="lg" 
              className="btn-primary text-lg px-8 py-6"
              onClick={() => document.getElementById('events-section').scrollIntoView({ behavior: 'smooth' })}
            >
              <Search className="w-5 h-5 mr-2" />
              Find Events Near You
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Events Section */}
      <section id="events-section" className="section-padding bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-gradient">Upcoming Events</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover exciting street sports events happening in your area. Join the community and make new friends!
            </p>
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
              {/* Sport Filters */}
              <div className="flex flex-wrap gap-2">
                {sports.map((sport) => (
                  <Button
                    key={sport.id}
                    variant={selectedSport === sport.id ? "default" : "outline"}
                    className={`filter-btn ${selectedSport === sport.id ? 'active' : ''}`}
                    onClick={() => setSelectedSport(sport.id)}
                  >
                    <span className="mr-2">{sport.icon}</span>
                    {sport.name}
                  </Button>
                ))}
              </div>

              {/* Search and Date Filter */}
              <div className="flex gap-2 w-full lg:w-auto">
                <div className="relative flex-1 lg:w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search events..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Date" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Dates</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="tomorrow">Tomorrow</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </motion.div>

          {/* Events Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -30 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="event-card card-hover overflow-hidden">
                    <div className="relative">
                      <img
                        src={event.image}
                        alt={event.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4 flex gap-2">
                        <Button
                          size="icon"
                          variant="secondary"
                          className="glass-effect"
                          onClick={() => toggleLike(event.id)}
                        >
                          <Heart 
                            className={`w-4 h-4 ${likedEvents.has(event.id) ? 'fill-red-500 text-red-500' : ''}`} 
                          />
                        </Button>
                        <Button size="icon" variant="secondary" className="glass-effect">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="absolute bottom-4 left-4">
                        <Badge className="bg-primary text-primary-foreground">
                          {sports.find(s => s.id === event.sport)?.icon} {sports.find(s => s.id === event.sport)?.name}
                        </Badge>
                      </div>
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="text-xl">{event.title}</CardTitle>
                      <CardDescription className="text-sm">
                        Organized by {event.organizer}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {event.description}
                      </p>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-primary" />
                          <a 
                            href={event.locationLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary hover:underline"
                          >
                            {event.location}
                          </a>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-primary" />
                          <span>{formatDate(event.date)}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-primary" />
                          <span>{formatTime(event.date)}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-primary" />
                          <span>{event.participants}/{event.maxParticipants} participants</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {event.tags.map((tag, tagIndex) => (
                          <Badge key={tagIndex} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <Button className="w-full btn-primary">
                        Join Event
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {filteredEvents.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-semibold mb-2">No events found</h3>
              <p className="text-muted-foreground">Try adjusting your filters or search terms.</p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground section-padding">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">Vibekhel</h3>
              <p className="text-primary-foreground/80">
                Connecting India's street sports community, one game at a time.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">About Us</a>
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">How It Works</a>
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">Community Guidelines</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <div className="space-y-2">
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">Help Center</a>
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">Contact Us</a>
                <a href="#" className="block text-primary-foreground/80 hover:text-primary-foreground transition-colors">Terms of Service</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="https://www.youtube.com/@vibe-khel" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  YouTube
                </a>
                <a href="https://www.instagram.com/vibekhel?igsh=MjliaTlqMTVtMzc=" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Instagram
                </a>
                <a href="https://www.linkedin.com/posts/challakalyan1729_gullysports-cricket-football-activity-7345925472414855169-qiJT" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  LinkedIn
                </a>
                <a href="https://x.com/Vibekhel?t=P7eO2PizXhDNeL9t1c3IYg&s=09" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  X (Twitter)
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
            <p className="text-primary-foreground/80">
              © 2025 Vibekhel. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Create Event Dialog Component
function CreateEventDialog({ onSubmit }) {
  const [formData, setFormData] = useState({
    title: '',
    sport: '',
    datetime: '',
    location: '',
    description: '',
    maxParticipants: ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(formData)
    setFormData({
      title: '',
      sport: '',
      datetime: '',
      location: '',
      description: '',
      maxParticipants: ''
    })
  }

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle>Create New Event</DialogTitle>
        <DialogDescription>
          Organize a street sports event in your community.
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="title">Event Title</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="e.g., Gully Cricket Tournament"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="sport">Sport</Label>
          <Select value={formData.sport} onValueChange={(value) => setFormData({ ...formData, sport: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select a sport" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cricket">🏏 Cricket</SelectItem>
              <SelectItem value="kabaddi">🤼 Kabaddi</SelectItem>
              <SelectItem value="chess">♟️ Chess</SelectItem>
              <SelectItem value="volleyball">🏐 Volleyball</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="datetime">Date & Time</Label>
          <Input
            id="datetime"
            type="datetime-local"
            value={formData.datetime}
            onChange={(e) => setFormData({ ...formData, datetime: e.target.value })}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g., Community Ground, City Name"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="maxParticipants">Max Participants</Label>
          <Input
            id="maxParticipants"
            type="number"
            value={formData.maxParticipants}
            onChange={(e) => setFormData({ ...formData, maxParticipants: e.target.value })}
            placeholder="e.g., 20"
            min="2"
          />
        </div>
        
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Describe your event..."
            rows={3}
          />
        </div>
        
        <Button type="submit" className="w-full btn-primary">
          Create Event
        </Button>
      </form>
    </DialogContent>
  )
}

export default App

